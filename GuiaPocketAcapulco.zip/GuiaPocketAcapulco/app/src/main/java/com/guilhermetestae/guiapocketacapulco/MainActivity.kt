package com.guilhermetestae.guiapocketacapulco

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.guilhermetestae.guiapocketacapulco.adapter.ServicoAdapter
import com.guilhermetestae.guiapocketacapulco.databinding.ActivityMainBinding
import com.guilhermetestae.guiapocketacapulco.model.Servico

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var servicos: List<Servico>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        carregarServicos()
        configurarListView()
    }

    private fun carregarServicos() {
        servicos = listOf(
            Servico(
                id = 1,
                nome = "TNT Auto Eletro",
                categoria = getString(R.string.categoria_oficina),
                endereco = "Av. Pedro Paulo Antonietto",
                telefone = "(16) 3333-4444",
                descricao = "Especializada em elétrica automotiva",
                imagem = R.mipmap.ic_launcher
            ),
            Servico(
                id = 2,
                nome = "Garagem 109",
                categoria = getString(R.string.categoria_oficina),
                endereco = "Av. Pedro Paulo Antonietto",
                telefone = "(16) 3333-5555",
                descricao = "Oficina mecânica e serviços automotivos",
                imagem = R.mipmap.ic_launcher
            ),
            Servico(
                id = 3,
                nome = "Emporio Pastel",
                categoria = getString(R.string.categoria_alimentacao),
                endereco = "Av. Pedro Paulo Antonietto",
                telefone = "(16) 3333-6666",
                descricao = "Lanches e pastéis",
                imagem = R.mipmap.ic_launcher
            ),
            Servico(
                id = 4,
                nome = "GTS Borracharia e Rodas",
                categoria = getString(R.string.categoria_oficina),
                endereco = "Av. Antonio Honorio Real",
                telefone = "(16) 3333-7777",
                descricao = "Borracharia e serviços de rodas",
                imagem = R.mipmap.ic_launcher
            ),
            Servico(
                id = 5,
                nome = "Super Mercado e Acougue Acapulco",
                categoria = getString(R.string.categoria_mercado),
                endereco = "Av. Antonio Honorio Real",
                telefone = "(16) 3333-8888",
                descricao = "Mercado e acougue do bairro",
                imagem = R.mipmap.ic_launcher
            ),
            Servico(
                id = 6,
                nome = "Distribuidora Piassi",
                categoria = getString(R.string.categoria_distribuidora),
                endereco = "Av. Pedro Paulo Antonietto",
                telefone = "(16) 3333-9999",
                descricao = "Distribuidora de bebidas",
                imagem = R.mipmap.ic_launcher
            )
        )
    }

    private fun configurarListView() {
        val adapter = ServicoAdapter(this, servicos)
        binding.listViewServicos.adapter = adapter

        binding.listViewServicos.setOnItemClickListener { _, _, position, _ ->
            val servico = servicos[position]
            val intent = Intent(this, DetalhesServicoActivity::class.java)
            intent.putExtra("SERVICO", servico)
            startActivity(intent)
        }
    }
}