package com.guilhermetestae.guiapocketacapulco.model

import java.io.Serializable

data class Servico(
    val id: Int,
    val nome: String,
    val categoria: String,
    val endereco: String,
    val telefone: String,
    val descricao: String,
    val imagem: Int = 0
) : Serializable