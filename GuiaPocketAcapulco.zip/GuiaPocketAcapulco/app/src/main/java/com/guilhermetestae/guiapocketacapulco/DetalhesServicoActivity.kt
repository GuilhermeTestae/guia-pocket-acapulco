package com.guilhermetestae.guiapocketacapulco

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.guilhermetestae.guiapocketacapulco.databinding.ActivityDetalhesServicoBinding
import com.guilhermetestae.guiapocketacapulco.model.Servico

class DetalhesServicoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetalhesServicoBinding
    private lateinit var servico: Servico

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetalhesServicoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        carregarServico()
        configurarViews()
        configurarBotoes()
    }

    private fun carregarServico() {
        servico = intent.getSerializableExtra("SERVICO") as Servico
    }

    private fun configurarViews() {
        binding.tvNomeDetalhe.text = servico.nome
        binding.tvCategoriaDetalhe.text = servico.categoria
        binding.tvEnderecoDetalhe.text = "Endereço: ${servico.endereco}"
        binding.tvTelefoneDetalhe.text = "Telefone: ${servico.telefone}"
        binding.tvDescricaoDetalhe.text = "Descrição: ${servico.descricao}"
        binding.imgServicoDetalhe.setImageResource(servico.imagem)
    }

    private fun configurarBotoes() {
        binding.btnLigar.setOnClickListener {
            val intent = Intent(Intent.ACTION_DIAL)
            intent.data = Uri.parse("tel:${servico.telefone}")
            startActivity(intent)
        }

        binding.btnMapa.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse("geo:0,0?q=${servico.endereco}")
            startActivity(intent)
        }

        binding.btnCompartilhar.setOnClickListener {
            val shareIntent = Intent(Intent.ACTION_SEND)
            shareIntent.type = "text/plain"
            shareIntent.putExtra(Intent.EXTRA_TEXT,
                "Confira ${servico.nome} - ${servico.descricao}\nEndereço: ${servico.endereco}\nTelefone: ${servico.telefone}")
            startActivity(Intent.createChooser(shareIntent, "Compartilhar via"))
        }

        binding.btnVoltar.setOnClickListener {
            finish()
        }
    }
}